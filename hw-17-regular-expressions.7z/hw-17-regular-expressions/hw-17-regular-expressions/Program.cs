﻿using System.Text.RegularExpressions;

class InputValidator
{
    public void ValidateSurnameAndInitials()
    {
        string regex = @"^([A-ZА-Я][a-zа-я]+)\s([A-ZА-Я]\.[A-ZА-Я]\.|[A-ZА-Я]{2})$";

        while (true)
        {
            Console.WriteLine("Enter surname and initials in the format 'Smith J.D.' or 'Smith JD':");
            string input = Console.ReadLine();

            if (Regex.IsMatch(input, regex))
            {
                Console.WriteLine("Input is valid.");
                break;
            }
            else
            {
                Console.WriteLine("Error! Invalid format. Please try again.");
            }
        }
    }

    public void ValidateEmail()
    {
        string regex = @"^[a-zA-Z][a-zA-Z0-9_]{2,15}@[a-zA-Z0-9-]+\.[a-zA-Z]{2,3}$";

        while (true)
        {
            Console.WriteLine("Enter an email address in the format 'login@host.com':");
            string input = Console.ReadLine();

            if (Regex.IsMatch(input, regex))
            {
                Console.WriteLine("Email address is valid.");
                break;
            }
            else
            {
                Console.WriteLine("Error! Invalid email format. Please try again.");
            }
        }
    }

    public void ValidateDate()
    {
        string regex = @"^(0[1-9]|[12][0-9]|3[01])-(0[1-9]|1[0-2])-\d{4}$";

        while (true)
        {
            Console.WriteLine("Enter a date in the format 'Day-Month-Year' (e.g., 01-04-2015):");
            string input = Console.ReadLine();

            if (Regex.IsMatch(input, regex))
            {
                Console.WriteLine("Date is valid.");
                break;
            }
            else
            {
                Console.WriteLine("Error! Invalid date format. Please try again.");
            }
        }
    }
}

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        var validator = new InputValidator();

        validator.ValidateSurnameAndInitials();
        validator.ValidateEmail();
        validator.ValidateDate();
    }
}
